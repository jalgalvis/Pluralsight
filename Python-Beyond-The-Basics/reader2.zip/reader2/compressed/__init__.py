from reader2.reader2.compressed.bzipped import opener as bz2_opener

__all__ = ['bz2_opener', 'gzip_opener']